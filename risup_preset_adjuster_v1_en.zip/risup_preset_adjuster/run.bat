@echo off
chcp 65001 >nul
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    set "PY=py -3"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo Python 3 is required.
        echo Please install Python 3 and enable Add Python to PATH.
        pause
        exit /b 1
    )
    set "PY=python"
)

%PY% "%~dp0risup_adjust.py"
echo.
pause
