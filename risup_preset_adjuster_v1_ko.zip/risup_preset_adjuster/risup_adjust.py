#!/usr/bin/env python3
import gzip
import hashlib
import importlib
import subprocess
import sys
import zlib
from pathlib import Path

VERSION = "1.0.0"
WINDOW_START = -10
REMOVE_TYPES = {"description", "lorebook", "memory"}

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "input"
OUTPUT = ROOT / "output"
RPACK_MAP = ROOT / "rpack_map.bin"
DEPS_DIR = ROOT / ".pydeps"
KEY = hashlib.sha256(b"risupreset").digest()
IV = bytes(12)
DROP = object()


def import_dependencies():
    msgpack_module = importlib.import_module("msgpack")
    aes_module = importlib.import_module("cryptography.hazmat.primitives.ciphers.aead")
    return msgpack_module, aes_module.AESGCM


def ensure_dependencies():
    deps_path = str(DEPS_DIR)
    if DEPS_DIR.exists() and deps_path not in sys.path:
        sys.path.insert(0, deps_path)

    try:
        return import_dependencies()
    except ImportError:
        pass

    print("필수 Python 패키지를 설치합니다: msgpack, cryptography")
    DEPS_DIR.mkdir(parents=True, exist_ok=True)
    command = [
        sys.executable,
        "-m",
        "pip",
        "install",
        "--disable-pip-version-check",
        "--no-input",
        "--target",
        deps_path,
        "msgpack",
        "cryptography",
    ]

    try:
        subprocess.check_call(command)
    except subprocess.CalledProcessError:
        try:
            subprocess.check_call([sys.executable, "-m", "ensurepip", "--upgrade"])
            subprocess.check_call(command)
        except (subprocess.CalledProcessError, OSError) as exc:
            raise RuntimeError(
                "msgpack / cryptography를 자동으로 설치하지 못했습니다. "
                "인터넷 연결과 Python의 pip 설치 상태를 확인해 주세요."
            ) from exc

    if deps_path not in sys.path:
        sys.path.insert(0, deps_path)
    importlib.invalidate_caches()

    try:
        return import_dependencies()
    except ImportError as exc:
        raise RuntimeError(
            "패키지는 설치되었지만 .pydeps/ 폴더에서 불러오지 못했습니다."
        ) from exc


msgpack, AESGCM = ensure_dependencies()


def load_maps():
    data = RPACK_MAP.read_bytes()
    if len(data) < 512:
        raise ValueError("rpack_map.bin 파일이 없거나 올바르지 않습니다.")
    return data[:256], data[256:512]


def decompress(data):
    if data[:3] == b"\x1f\x8b\x08":
        return gzip.decompress(data)
    try:
        return zlib.decompress(data)
    except zlib.error:
        return zlib.decompress(data, -zlib.MAX_WBITS)


def decode_risup(path):
    _, decode_map = load_maps()
    raw = bytes(decode_map[b] for b in path.read_bytes())
    container = msgpack.unpackb(decompress(raw), raw=False, strict_map_key=False)

    if not isinstance(container, dict) or container.get("type") != "preset":
        raise ValueError("지원하지 않는 .risup 프리셋입니다.")

    field = "preset" if isinstance(container.get("preset"), (bytes, bytearray)) else "pres"
    encrypted = container.get(field)
    if not isinstance(encrypted, (bytes, bytearray)):
        raise ValueError("암호화된 프리셋 데이터를 찾을 수 없습니다.")

    preset = msgpack.unpackb(
        AESGCM(KEY).decrypt(IV, bytes(encrypted), None),
        raw=False,
        strict_map_key=False,
    )
    if not isinstance(preset, dict):
        raise ValueError("복호화된 프리셋의 최상위 데이터가 객체 형식이 아닙니다.")

    return preset, container, field


def encode_risup(preset, container, field):
    encode_map, _ = load_maps()
    packed = msgpack.packb(preset, use_bin_type=True)
    container = dict(container)
    container[field] = AESGCM(KEY).encrypt(IV, packed, None)
    compressed = gzip.compress(
        msgpack.packb(container, use_bin_type=True), compresslevel=6, mtime=0
    )
    return bytes(encode_map[b] for b in compressed)


def is_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def is_chat(value):
    return isinstance(value, dict) and value.get("type") == "chat"


def reaches_window(range_end):
    return range_end == "end" or (
        is_int(range_end) and WINDOW_START < range_end < 0
    )


def chat_label(chat, index):
    name = chat.get("name")
    if isinstance(name, str) and name.strip():
        return name.strip()
    return f"채팅 항목 #{index + 1}"


def assert_safe_to_drop(chat, index):
    for key in ("text", "innerFormat", "defaultText"):
        value = chat.get(key)
        if isinstance(value, str) and value.strip():
            raise ValueError(
                f"기존 {chat_label(chat, index)!r} 항목을 안전하게 제거할 수 없습니다: "
                f"비어 있지 않은 {key} 값이 삭제됩니다."
            )


def validate_ranges(chats):
    if not chats:
        raise ValueError('범위를 조정한 뒤 남아 있는 "type": "chat" 항목이 없습니다.')
    if chats[0].get("rangeStart") != WINDOW_START:
        raise ValueError(f"첫 번째 채팅 항목의 rangeStart 값은 {WINDOW_START}이어야 합니다.")
    if chats[-1].get("rangeEnd") != "end":
        raise ValueError('마지막 채팅 항목의 rangeEnd 값은 "end"여야 합니다.')

    for index, chat in enumerate(chats[:-1]):
        boundary = chat.get("rangeEnd")
        next_start = chats[index + 1].get("rangeStart")
        if not (is_int(boundary) and WINDOW_START < boundary < 0):
            raise ValueError(
                f"{chat_label(chat, index)!r} 항목의 중간 "
                f"rangeEnd 값({boundary!r})은 지원하지 않습니다."
            )
        if next_start != boundary:
            raise ValueError(
                f"채팅 범위가 연속적이지 않습니다: {boundary!r} -> {next_start!r}"
            )


def crop_chat_list(items, stats):
    chats = [item for item in items if is_chat(item)]
    if not chats:
        return items

    stats["chat_total"] += len(chats)
    first_keep = next(
        (index for index, chat in enumerate(chats) if reaches_window(chat.get("rangeEnd"))),
        len(chats) - 1,
    )

    dropped = chats[:first_keep]
    kept = chats[first_keep:]

    for index, chat in enumerate(dropped):
        assert_safe_to_drop(chat, index)

    kept[0]["rangeStart"] = WINDOW_START
    kept[-1]["rangeEnd"] = "end"
    validate_ranges(kept)

    stats["chat_dropped"] += len(dropped)
    stats["chat_kept"] += len(kept)
    dropped_ids = {id(chat) for chat in dropped}
    return [item for item in items if id(item) not in dropped_ids]


def transform(value, stats, parent_is_list=False):
    if isinstance(value, dict):
        entry_type = value.get("type")
        if entry_type in REMOVE_TYPES:
            stats["removed_types"][entry_type] += 1
            return DROP

        for key in list(value):
            updated = transform(value[key], stats)
            if updated is DROP:
                del value[key]
            else:
                value[key] = updated

        if entry_type == "chat" and not parent_is_list:
            stats["chat_total"] += 1
            stats["chat_kept"] += 1
            value["rangeStart"] = WINDOW_START
            value["rangeEnd"] = "end"
        return value

    if isinstance(value, list):
        cleaned = []
        for item in value:
            updated = transform(item, stats, parent_is_list=True)
            if updated is not DROP:
                cleaned.append(updated)
        return crop_chat_list(cleaned, stats)

    return value


def adjust(preset):
    stats = {
        "chat_total": 0,
        "chat_kept": 0,
        "chat_dropped": 0,
        "removed_types": {entry_type: 0 for entry_type in REMOVE_TYPES},
    }
    preset = transform(preset, stats)
    if stats["chat_total"] == 0:
        raise ValueError('"type": "chat" 항목을 찾을 수 없습니다.')
    return preset, stats


def main():
    INPUT.mkdir(exist_ok=True)
    OUTPUT.mkdir(exist_ok=True)
    files = sorted(INPUT.glob("*.risup"))

    if not files:
        print("input/ 폴더에 .risup 파일이 없습니다.")
        return 1

    print(f"RisuAI 프리셋 조정 도구 v{VERSION}")
    completed = 0

    for source in files:
        try:
            preset, container, field = decode_risup(source)
            preset, stats = adjust(preset)
            target = OUTPUT / source.name
            target.write_bytes(encode_risup(preset, container, field))
            removed = stats["removed_types"]
            print(
                f"[완료] {source.name} "
                f"(채팅 {stats['chat_total']}개 -> {stats['chat_kept']}개; "
                f"삭제: 설명 {removed['description']}개, "
                f"로어북 {removed['lorebook']}개, 메모리 {removed['memory']}개)"
            )
            completed += 1
        except Exception as exc:
            print(f"[오류] {source.name}: {exc}")

    if completed:
        print()
        print("프리셋 조정이 완료되었습니다!")

    return 0 if completed == len(files) else 1


if __name__ == "__main__":
    raise SystemExit(main())
