@echo off
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    set "PY=py -3"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo Python 3가 필요합니다.
        echo Python 3를 설치할 때 'Add Python to PATH' 옵션을 선택해 주세요.
        echo 계속하려면 아무 키나 누르세요 . . .
        pause >nul
        exit /b 1
    )
    set "PY=python"
)

%PY% "%~dp0risup_adjust.py"
echo.
echo 계속하려면 아무 키나 누르세요 . . .
pause >nul
