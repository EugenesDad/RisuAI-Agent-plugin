RisuAI Preset Adjuster v1.0.0

使用方式
1. 將 .risup 放入 input 資料夾。
2. Windows：雙擊 run.bat。
3. macOS / Linux：執行 python3 risup_adjust.py 或 ./risup_adjust.py。
4. 完成檔案會輸出到 output 資料夾。

處理內容
- 移除 type = description / lorebook / memory。
- 將 chat 裁切到 -10 ~ end。
- 保留 -10 ~ end 內原有的有效 chat 分界。
- 不安全或不連續的 chat 結構會停止處理，不輸出該 preset。

依賴
- Python 3
- msgpack / cryptography
- 缺少套件時會自動安裝到 .pydeps。
- rpack_map.bin 必須與 risup_adjust.py 位於同一資料夾。

macOS / Linux 若 executable 權限遺失：
chmod +x risup_adjust.py
