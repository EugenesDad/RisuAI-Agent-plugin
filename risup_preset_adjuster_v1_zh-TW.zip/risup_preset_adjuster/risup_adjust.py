#!/usr/bin/env python3
import gzip
import hashlib
import importlib
import subprocess
import sys
import zlib
from pathlib import Path

VERSION = "1.0.0"
WINDOW_START = -10
REMOVE_TYPES = {"description", "lorebook", "memory"}

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "input"
OUTPUT = ROOT / "output"
RPACK_MAP = ROOT / "rpack_map.bin"
DEPS_DIR = ROOT / ".pydeps"
KEY = hashlib.sha256(b"risupreset").digest()
IV = bytes(12)
DROP = object()


def import_dependencies():
    msgpack_module = importlib.import_module("msgpack")
    aes_module = importlib.import_module("cryptography.hazmat.primitives.ciphers.aead")
    return msgpack_module, aes_module.AESGCM


def ensure_dependencies():
    deps_path = str(DEPS_DIR)
    if DEPS_DIR.exists() and deps_path not in sys.path:
        sys.path.insert(0, deps_path)

    try:
        return import_dependencies()
    except ImportError:
        pass

    print("Installing required Python packages: msgpack, cryptography")
    DEPS_DIR.mkdir(parents=True, exist_ok=True)
    command = [
        sys.executable,
        "-m",
        "pip",
        "install",
        "--disable-pip-version-check",
        "--no-input",
        "--target",
        deps_path,
        "msgpack",
        "cryptography",
    ]

    try:
        subprocess.check_call(command)
    except subprocess.CalledProcessError:
        try:
            subprocess.check_call([sys.executable, "-m", "ensurepip", "--upgrade"])
            subprocess.check_call(command)
        except (subprocess.CalledProcessError, OSError) as exc:
            raise RuntimeError(
                "Could not install msgpack / cryptography automatically. "
                "Check the internet connection and Python pip installation."
            ) from exc

    if deps_path not in sys.path:
        sys.path.insert(0, deps_path)
    importlib.invalidate_caches()

    try:
        return import_dependencies()
    except ImportError as exc:
        raise RuntimeError(
            "Dependencies were installed but could not be imported from .pydeps/."
        ) from exc


msgpack, AESGCM = ensure_dependencies()


def load_maps():
    data = RPACK_MAP.read_bytes()
    if len(data) < 512:
        raise ValueError("rpack_map.bin is missing or invalid")
    return data[:256], data[256:512]


def decompress(data):
    if data[:3] == b"\x1f\x8b\x08":
        return gzip.decompress(data)
    try:
        return zlib.decompress(data)
    except zlib.error:
        return zlib.decompress(data, -zlib.MAX_WBITS)


def decode_risup(path):
    _, decode_map = load_maps()
    raw = bytes(decode_map[b] for b in path.read_bytes())
    container = msgpack.unpackb(decompress(raw), raw=False, strict_map_key=False)

    if not isinstance(container, dict) or container.get("type") != "preset":
        raise ValueError("unsupported .risup preset")

    field = "preset" if isinstance(container.get("preset"), (bytes, bytearray)) else "pres"
    encrypted = container.get(field)
    if not isinstance(encrypted, (bytes, bytearray)):
        raise ValueError("encrypted preset payload not found")

    preset = msgpack.unpackb(
        AESGCM(KEY).decrypt(IV, bytes(encrypted), None),
        raw=False,
        strict_map_key=False,
    )
    if not isinstance(preset, dict):
        raise ValueError("decoded preset root is not an object")

    return preset, container, field


def encode_risup(preset, container, field):
    encode_map, _ = load_maps()
    packed = msgpack.packb(preset, use_bin_type=True)
    container = dict(container)
    container[field] = AESGCM(KEY).encrypt(IV, packed, None)
    compressed = gzip.compress(
        msgpack.packb(container, use_bin_type=True), compresslevel=6, mtime=0
    )
    return bytes(encode_map[b] for b in compressed)


def is_int(value):
    return isinstance(value, int) and not isinstance(value, bool)


def is_chat(value):
    return isinstance(value, dict) and value.get("type") == "chat"


def reaches_window(range_end):
    return range_end == "end" or (
        is_int(range_end) and WINDOW_START < range_end < 0
    )


def chat_label(chat, index):
    name = chat.get("name")
    if isinstance(name, str) and name.strip():
        return name.strip()
    return f"chat #{index + 1}"


def assert_safe_to_drop(chat, index):
    for key in ("text", "innerFormat", "defaultText"):
        value = chat.get(key)
        if isinstance(value, str) and value.strip():
            raise ValueError(
                f"cannot safely remove old {chat_label(chat, index)!r}: "
                f"non-empty {key} would be discarded"
            )


def validate_ranges(chats):
    if not chats:
        raise ValueError('no "type": "chat" entries remain after cropping')
    if chats[0].get("rangeStart") != WINDOW_START:
        raise ValueError(f"first chat rangeStart must be {WINDOW_START}")
    if chats[-1].get("rangeEnd") != "end":
        raise ValueError('last chat rangeEnd must be "end"')

    for index, chat in enumerate(chats[:-1]):
        boundary = chat.get("rangeEnd")
        next_start = chats[index + 1].get("rangeStart")
        if not (is_int(boundary) and WINDOW_START < boundary < 0):
            raise ValueError(
                f"{chat_label(chat, index)!r} has unsupported interior "
                f"rangeEnd {boundary!r}"
            )
        if next_start != boundary:
            raise ValueError(
                f"chat ranges are not connected: {boundary!r} -> {next_start!r}"
            )


def crop_chat_list(items, stats):
    chats = [item for item in items if is_chat(item)]
    if not chats:
        return items

    stats["chat_total"] += len(chats)
    first_keep = next(
        (index for index, chat in enumerate(chats) if reaches_window(chat.get("rangeEnd"))),
        len(chats) - 1,
    )

    dropped = chats[:first_keep]
    kept = chats[first_keep:]

    for index, chat in enumerate(dropped):
        assert_safe_to_drop(chat, index)

    kept[0]["rangeStart"] = WINDOW_START
    kept[-1]["rangeEnd"] = "end"
    validate_ranges(kept)

    stats["chat_dropped"] += len(dropped)
    stats["chat_kept"] += len(kept)
    dropped_ids = {id(chat) for chat in dropped}
    return [item for item in items if id(item) not in dropped_ids]


def transform(value, stats, parent_is_list=False):
    if isinstance(value, dict):
        entry_type = value.get("type")
        if entry_type in REMOVE_TYPES:
            stats["removed_types"][entry_type] += 1
            return DROP

        for key in list(value):
            updated = transform(value[key], stats)
            if updated is DROP:
                del value[key]
            else:
                value[key] = updated

        if entry_type == "chat" and not parent_is_list:
            stats["chat_total"] += 1
            stats["chat_kept"] += 1
            value["rangeStart"] = WINDOW_START
            value["rangeEnd"] = "end"
        return value

    if isinstance(value, list):
        cleaned = []
        for item in value:
            updated = transform(item, stats, parent_is_list=True)
            if updated is not DROP:
                cleaned.append(updated)
        return crop_chat_list(cleaned, stats)

    return value


def adjust(preset):
    stats = {
        "chat_total": 0,
        "chat_kept": 0,
        "chat_dropped": 0,
        "removed_types": {entry_type: 0 for entry_type in REMOVE_TYPES},
    }
    preset = transform(preset, stats)
    if stats["chat_total"] == 0:
        raise ValueError('no "type": "chat" entries found')
    return preset, stats


def main():
    INPUT.mkdir(exist_ok=True)
    OUTPUT.mkdir(exist_ok=True)
    files = sorted(INPUT.glob("*.risup"))

    if not files:
        print("No .risup files found in input/")
        return 1

    print(f"RisuAI Preset Adjuster v{VERSION}")
    completed = 0

    for source in files:
        try:
            preset, container, field = decode_risup(source)
            preset, stats = adjust(preset)
            target = OUTPUT / source.name
            target.write_bytes(encode_risup(preset, container, field))
            removed = stats["removed_types"]
            print(
                f"[OK] {source.name} "
                f"(chat {stats['chat_total']} -> {stats['chat_kept']}; "
                f"removed {removed['description']}/"
                f"{removed['lorebook']}/{removed['memory']})"
            )
            completed += 1
        except Exception as exc:
            print(f"[ERROR] {source.name}: {exc}")

    if completed:
        print()
        print("Preset 已完成調整！")
        print("Preset adjustment completed!")
        print("프리셋 조정이 완료되었습니다!")

    return 0 if completed == len(files) else 1


if __name__ == "__main__":
    raise SystemExit(main())
