RisuAI Preset Adjuster v1.0.0

HOW TO USE
1. Place your .risup preset files in the input/ folder.
2. Windows: Double-click run.bat.
3. macOS / Linux: Run python3 risup_adjust.py or ./risup_adjust.py.
4. Adjusted preset files will be saved in the output/ folder.

WHAT THE TOOL DOES
- Removes entries with type = description, lorebook, or memory.
- Crops the chat range to -10 through end.
- Preserves valid existing chat boundaries within the -10 to end range.
- Stops processing unsafe or disconnected chat structures without writing
  an output file for the affected preset.

REQUIREMENTS
- Python 3
- Python packages: msgpack and cryptography
- Missing packages are automatically installed into the local .pydeps/ folder.
- Keep rpack_map.bin in the same folder as risup_adjust.py.

macOS / Linux: If executable permission is missing, run:
chmod +x risup_adjust.py
