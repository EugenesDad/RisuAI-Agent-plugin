RisuAI 프리셋 조정 도구 v1.0.0 (한국어판)

사용 방법
먼저 ZIP 파일의 압축을 풀어 주세요.
1. 조정할 .risup 파일을 input 폴더에 넣습니다.
2. Windows: run.bat 파일을 두 번 클릭합니다.
3. macOS / Linux: 터미널에서 도구 폴더로 이동한 뒤
   python3 risup_adjust.py 또는 ./risup_adjust.py를 실행합니다.
4. 조정이 완료된 파일은 원본과 같은 이름으로 output 폴더에 저장됩니다.

조정 내용
- type 값이 description(설명), lorebook(로어북), memory(메모리)인 항목을 제거합니다.
- chat(채팅) 범위를 -10 ~ end로 조정합니다.
- -10 ~ end 범위 안에 있는 기존의 유효한 채팅 구간 경계를 유지합니다.
- 채팅 구조를 안전하게 조정할 수 없거나 구간이 연속적이지 않으면
  해당 프리셋의 처리를 중단하고 결과 파일을 생성하지 않습니다.

필수 구성 요소
- Python 3
- msgpack / cryptography 패키지
- 필요한 패키지가 없으면 .pydeps 폴더에 자동으로 설치합니다.
  자동 설치 시 인터넷 연결이 필요합니다.
- rpack_map.bin 파일은 risup_adjust.py와 같은 폴더에 있어야 합니다.

macOS / Linux에서 실행 권한이 없으면 다음 명령을 실행하세요:
chmod +x risup_adjust.py
